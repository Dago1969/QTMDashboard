import * as i0 from '@angular/core';
import { Injectable, Component, EventEmitter, Input, Output } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

class QtmSharedService {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmSharedService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmSharedService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmSharedService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class QtmSharedComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmSharedComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.11", type: QtmSharedComponent, isStandalone: true, selector: "qtm-qtm-shared", ngImport: i0, template: `
    <p>
      qtm-shared works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmSharedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'qtm-qtm-shared', standalone: true, imports: [], template: `
    <p>
      qtm-shared works!
    </p>
  ` }]
        }] });

class QtmButtonComponent {
    variant = 'primary';
    type = 'button';
    href;
    routerLink;
    disabled = false;
    icon;
    label = '';
    btnClick = new EventEmitter();
    handleNavigationClick(event) {
        if (this.disabled) {
            event.preventDefault();
            event.stopPropagation();
            return;
        }
        this.emitClick(event);
    }
    emitClick(event) {
        this.btnClick.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.11", type: QtmButtonComponent, isStandalone: true, selector: "qtm-button", inputs: { variant: "variant", type: "type", href: "href", routerLink: "routerLink", disabled: "disabled", icon: "icon", label: "label" }, outputs: { btnClick: "btnClick" }, ngImport: i0, template: `
    <a
      *ngIf="(routerLink !== undefined && routerLink !== null) || !!href"
      class="qtm-button"
      [ngClass]="'qtm-button--' + variant"
      [routerLink]="disabled ? null : routerLink"
      [href]="routerLink !== undefined && routerLink !== null ? null : (disabled ? null : href)"
      [attr.aria-disabled]="disabled"
      [attr.tabindex]="disabled ? -1 : null"
      (click)="handleNavigationClick($event)"
    >
      <span class="qtm-button__icon" aria-hidden="true" [hidden]="!icon">{{ icon }}</span>
      {{ label }}
    </a>

    <button
      *ngIf="(routerLink === undefined || routerLink === null) && !href"
      class="qtm-button"
      [ngClass]="'qtm-button--' + variant"
      [type]="type"
      [disabled]="disabled"
      (click)="emitClick($event)"
    >
      <span class="qtm-button__icon" aria-hidden="true" [hidden]="!icon">{{ icon }}</span>
      {{ label }}
    </button>
  `, isInline: true, styles: [":host{display:inline-block;vertical-align:middle}.qtm-button{align-items:center;box-sizing:border-box;border:1px solid transparent;border-radius:20px;cursor:pointer;display:inline-flex;font:inherit;font-size:13px;font-weight:600;gap:8px;height:40px;justify-content:center;line-height:1;margin:0;padding:0 18px;text-decoration:none;white-space:nowrap}.qtm-button--primary{background:#1687f8;border-color:#1687f8;color:#fff}.qtm-button--outline,.qtm-button--link,.qtm-button--nav{background:#fff;border-color:#1687f8;color:#075bd8}.qtm-button:hover:not(:disabled):not([aria-disabled=true]){filter:brightness(.96)}.qtm-button:focus-visible{outline:2px solid #084eaa;outline-offset:2px}.qtm-button:disabled,.qtm-button[aria-disabled=true]{cursor:not-allowed;opacity:.58}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'qtm-button', standalone: true, imports: [CommonModule, RouterLink], template: `
    <a
      *ngIf="(routerLink !== undefined && routerLink !== null) || !!href"
      class="qtm-button"
      [ngClass]="'qtm-button--' + variant"
      [routerLink]="disabled ? null : routerLink"
      [href]="routerLink !== undefined && routerLink !== null ? null : (disabled ? null : href)"
      [attr.aria-disabled]="disabled"
      [attr.tabindex]="disabled ? -1 : null"
      (click)="handleNavigationClick($event)"
    >
      <span class="qtm-button__icon" aria-hidden="true" [hidden]="!icon">{{ icon }}</span>
      {{ label }}
    </a>

    <button
      *ngIf="(routerLink === undefined || routerLink === null) && !href"
      class="qtm-button"
      [ngClass]="'qtm-button--' + variant"
      [type]="type"
      [disabled]="disabled"
      (click)="emitClick($event)"
    >
      <span class="qtm-button__icon" aria-hidden="true" [hidden]="!icon">{{ icon }}</span>
      {{ label }}
    </button>
  `, styles: [":host{display:inline-block;vertical-align:middle}.qtm-button{align-items:center;box-sizing:border-box;border:1px solid transparent;border-radius:20px;cursor:pointer;display:inline-flex;font:inherit;font-size:13px;font-weight:600;gap:8px;height:40px;justify-content:center;line-height:1;margin:0;padding:0 18px;text-decoration:none;white-space:nowrap}.qtm-button--primary{background:#1687f8;border-color:#1687f8;color:#fff}.qtm-button--outline,.qtm-button--link,.qtm-button--nav{background:#fff;border-color:#1687f8;color:#075bd8}.qtm-button:hover:not(:disabled):not([aria-disabled=true]){filter:brightness(.96)}.qtm-button:focus-visible{outline:2px solid #084eaa;outline-offset:2px}.qtm-button:disabled,.qtm-button[aria-disabled=true]{cursor:not-allowed;opacity:.58}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], type: [{
                type: Input
            }], href: [{
                type: Input
            }], routerLink: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], label: [{
                type: Input
            }], btnClick: [{
                type: Output
            }] } });

class QtmSortableTableComponent {
    columns = [];
    data = [];
    totalItems = 0;
    page = 0;
    pageSize = 10;
    pageSizeOptions = [5, 10, 25];
    currentSort = { active: undefined, direction: null };
    cellTemplates = {};
    emptyLabel = 'No items';
    pageLabel = 'Page';
    ofLabel = 'of';
    sortChange = new EventEmitter();
    pageChange = new EventEmitter();
    pageSizeChange = new EventEmitter();
    Math = Math;
    get safeColumns() {
        return Array.isArray(this.columns)
            ? this.columns.filter((column) => !!column && typeof column.key === 'string')
            : [];
    }
    get safeData() {
        return Array.isArray(this.data) ? this.data : [];
    }
    get safeCellTemplates() {
        return this.cellTemplates && typeof this.cellTemplates === 'object' ? this.cellTemplates : {};
    }
    getCellTemplate(key) {
        return this.safeCellTemplates[key] ?? null;
    }
    getColumnTemplate(column) {
        return this.getCellTemplate(column.key) ?? column.customTemplate ?? null;
    }
    get safeCurrentSort() {
        return this.currentSort ?? { active: undefined, direction: null };
    }
    get totalPages() {
        return Math.max(1, Math.ceil((this.totalItems ?? 0) / Math.max(1, this.pageSize ?? 10)));
    }
    toggleSort(column) {
        if (!column.sortable) {
            return;
        }
        const isActive = this.currentSort?.active === column.key;
        const direction = !isActive
            ? 'asc'
            : this.currentSort.direction === 'asc'
                ? 'desc'
                : this.currentSort.direction === 'desc'
                    ? null
                    : 'asc';
        this.sortChange.emit({
            active: direction ? column.key : undefined,
            direction
        });
    }
    sortIndicator(column) {
        if (!column.sortable || this.currentSort?.active !== column.key) {
            return '';
        }
        return this.currentSort.direction === 'asc' ? '▲' : this.currentSort.direction === 'desc' ? '▼' : '';
    }
    selectPageSize(value) {
        const pageSize = Number(value);
        if (Number.isInteger(pageSize) && pageSize > 0) {
            this.pageSizeChange.emit(pageSize);
        }
    }
    displayValue(row, column) {
        return row?.[column.key] ?? '-';
    }
    trackByIndex(index) {
        return index;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmSortableTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.11", type: QtmSortableTableComponent, isStandalone: true, selector: "qtm-sortable-table", inputs: { columns: "columns", data: "data", totalItems: "totalItems", page: "page", pageSize: "pageSize", pageSizeOptions: "pageSizeOptions", currentSort: "currentSort", cellTemplates: "cellTemplates", emptyLabel: "emptyLabel", pageLabel: "pageLabel", ofLabel: "ofLabel" }, outputs: { sortChange: "sortChange", pageChange: "pageChange", pageSizeChange: "pageSizeChange" }, ngImport: i0, template: "<div class=\"qtm-sortable-table\">\r\n  <div class=\"qtm-table-scroll\">\r\n    <table>\r\n      <thead>\r\n        <tr>\r\n          <th\r\n            *ngFor=\"let column of safeColumns\"\r\n            [class.qtm-sortable-header]=\"column.sortable\"\r\n            [attr.aria-sort]=\"safeCurrentSort.active === column.key ? (safeCurrentSort.direction === 'asc' ? 'ascending' : safeCurrentSort.direction === 'desc' ? 'descending' : 'none') : 'none'\"\r\n            (click)=\"toggleSort(column)\"\r\n          >\r\n            {{ column.label }}\r\n            <span *ngIf=\"column.sortable\" class=\"qtm-sort-indicator\" aria-hidden=\"true\">{{ sortIndicator(column) }}</span>\r\n          </th>\r\n        </tr>\r\n      </thead>\r\n      <tbody>\r\n        <tr *ngFor=\"let row of safeData; trackBy: trackByIndex\">\r\n          <td *ngFor=\"let column of safeColumns\">\r\n            <ng-container *ngIf=\"getColumnTemplate(column) as cellTemplate; else defaultCell\" [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ $implicit: row }\"></ng-container>\r\n            <ng-template #defaultCell>{{ displayValue(row, column) }}</ng-template>\r\n          </td>\r\n        </tr>\r\n        <tr *ngIf=\"safeData.length === 0\">\r\n          <td [attr.colspan]=\"safeColumns.length\" class=\"qtm-empty-cell\">{{ emptyLabel }}</td>\r\n        </tr>\r\n      </tbody>\r\n    </table>\r\n  </div>\r\n\r\n  <div *ngIf=\"totalItems > 0\" class=\"qtm-table-footer\">\r\n    <label>\r\n      <span>{{ pageSize }} / page</span>\r\n      <select [value]=\"pageSize\" (change)=\"selectPageSize($any($event.target).value)\">\r\n        <option *ngFor=\"let option of pageSizeOptions\" [value]=\"option\">{{ option }}</option>\r\n      </select>\r\n    </label>\r\n    <span>{{ page + 1 }} {{ ofLabel }} {{ totalPages }}</span>\r\n    <button type=\"button\" (click)=\"pageChange.emit(page - 1)\" [disabled]=\"page <= 0\">&lt;</button>\r\n    <button type=\"button\" (click)=\"pageChange.emit(page + 1)\" [disabled]=\"page + 1 >= totalPages\">&gt;</button>\r\n  </div>\r\n</div>", styles: [":host{display:block}.qtm-sortable-table{overflow:hidden;background:#fff;border:1px solid #e5e7eb;border-radius:8px}.qtm-table-scroll{overflow-x:auto}table{width:100%;border-collapse:collapse}th,td{padding:12px 16px;text-align:left;white-space:nowrap;border-bottom:1px solid #e5e7eb}th{color:#475569;font-size:12px;font-weight:700;text-transform:uppercase}.qtm-sortable-header{cursor:pointer}.qtm-sort-indicator{margin-left:6px}.qtm-empty-cell{padding:24px;text-align:center;color:#64748b}.qtm-table-footer{display:flex;align-items:center;justify-content:flex-end;gap:12px;padding:12px 16px}.qtm-table-footer label{display:inline-flex;align-items:center;gap:8px}.qtm-table-footer select,.qtm-table-footer button{min-height:32px;padding:4px 8px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: QtmSortableTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'qtm-sortable-table', standalone: true, imports: [CommonModule], template: "<div class=\"qtm-sortable-table\">\r\n  <div class=\"qtm-table-scroll\">\r\n    <table>\r\n      <thead>\r\n        <tr>\r\n          <th\r\n            *ngFor=\"let column of safeColumns\"\r\n            [class.qtm-sortable-header]=\"column.sortable\"\r\n            [attr.aria-sort]=\"safeCurrentSort.active === column.key ? (safeCurrentSort.direction === 'asc' ? 'ascending' : safeCurrentSort.direction === 'desc' ? 'descending' : 'none') : 'none'\"\r\n            (click)=\"toggleSort(column)\"\r\n          >\r\n            {{ column.label }}\r\n            <span *ngIf=\"column.sortable\" class=\"qtm-sort-indicator\" aria-hidden=\"true\">{{ sortIndicator(column) }}</span>\r\n          </th>\r\n        </tr>\r\n      </thead>\r\n      <tbody>\r\n        <tr *ngFor=\"let row of safeData; trackBy: trackByIndex\">\r\n          <td *ngFor=\"let column of safeColumns\">\r\n            <ng-container *ngIf=\"getColumnTemplate(column) as cellTemplate; else defaultCell\" [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ $implicit: row }\"></ng-container>\r\n            <ng-template #defaultCell>{{ displayValue(row, column) }}</ng-template>\r\n          </td>\r\n        </tr>\r\n        <tr *ngIf=\"safeData.length === 0\">\r\n          <td [attr.colspan]=\"safeColumns.length\" class=\"qtm-empty-cell\">{{ emptyLabel }}</td>\r\n        </tr>\r\n      </tbody>\r\n    </table>\r\n  </div>\r\n\r\n  <div *ngIf=\"totalItems > 0\" class=\"qtm-table-footer\">\r\n    <label>\r\n      <span>{{ pageSize }} / page</span>\r\n      <select [value]=\"pageSize\" (change)=\"selectPageSize($any($event.target).value)\">\r\n        <option *ngFor=\"let option of pageSizeOptions\" [value]=\"option\">{{ option }}</option>\r\n      </select>\r\n    </label>\r\n    <span>{{ page + 1 }} {{ ofLabel }} {{ totalPages }}</span>\r\n    <button type=\"button\" (click)=\"pageChange.emit(page - 1)\" [disabled]=\"page <= 0\">&lt;</button>\r\n    <button type=\"button\" (click)=\"pageChange.emit(page + 1)\" [disabled]=\"page + 1 >= totalPages\">&gt;</button>\r\n  </div>\r\n</div>", styles: [":host{display:block}.qtm-sortable-table{overflow:hidden;background:#fff;border:1px solid #e5e7eb;border-radius:8px}.qtm-table-scroll{overflow-x:auto}table{width:100%;border-collapse:collapse}th,td{padding:12px 16px;text-align:left;white-space:nowrap;border-bottom:1px solid #e5e7eb}th{color:#475569;font-size:12px;font-weight:700;text-transform:uppercase}.qtm-sortable-header{cursor:pointer}.qtm-sort-indicator{margin-left:6px}.qtm-empty-cell{padding:24px;text-align:center;color:#64748b}.qtm-table-footer{display:flex;align-items:center;justify-content:flex-end;gap:12px;padding:12px 16px}.qtm-table-footer label{display:inline-flex;align-items:center;gap:8px}.qtm-table-footer select,.qtm-table-footer button{min-height:32px;padding:4px 8px}\n"] }]
        }], propDecorators: { columns: [{
                type: Input
            }], data: [{
                type: Input
            }], totalItems: [{
                type: Input
            }], page: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], pageSizeOptions: [{
                type: Input
            }], currentSort: [{
                type: Input
            }], cellTemplates: [{
                type: Input
            }], emptyLabel: [{
                type: Input
            }], pageLabel: [{
                type: Input
            }], ofLabel: [{
                type: Input
            }], sortChange: [{
                type: Output
            }], pageChange: [{
                type: Output
            }], pageSizeChange: [{
                type: Output
            }] } });

/*
 * Public API Surface of qtm-shared
 */

/**
 * Generated bundle index. Do not edit.
 */

export { QtmButtonComponent, QtmSharedComponent, QtmSharedService, QtmSortableTableComponent };
//# sourceMappingURL=qtm-shared.mjs.map
