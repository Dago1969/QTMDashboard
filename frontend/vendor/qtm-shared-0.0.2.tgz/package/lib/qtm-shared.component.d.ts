import * as i0 from "@angular/core";
export declare class QtmSharedComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<QtmSharedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QtmSharedComponent, "qtm-qtm-shared", never, {}, {}, never, never, true, never>;
}
