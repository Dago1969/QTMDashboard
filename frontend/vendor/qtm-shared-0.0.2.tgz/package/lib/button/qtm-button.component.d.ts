import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type QtmButtonVariant = 'primary' | 'outline' | 'link' | 'nav';
export type QtmButtonType = 'button' | 'submit' | 'reset';
export declare class QtmButtonComponent {
    variant: QtmButtonVariant;
    type: QtmButtonType;
    href?: string;
    routerLink?: any;
    disabled: boolean;
    icon?: string;
    label: string;
    readonly btnClick: EventEmitter<MouseEvent>;
    handleNavigationClick(event: MouseEvent): void;
    emitClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QtmButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QtmButtonComponent, "qtm-button", never, { "variant": { "alias": "variant"; "required": false; }; "type": { "alias": "type"; "required": false; }; "href": { "alias": "href"; "required": false; }; "routerLink": { "alias": "routerLink"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, { "btnClick": "btnClick"; }, never, never, true, never>;
}
