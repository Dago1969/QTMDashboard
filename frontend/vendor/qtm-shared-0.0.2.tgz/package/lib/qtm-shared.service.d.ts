import * as i0 from "@angular/core";
export declare class QtmSharedService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<QtmSharedService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QtmSharedService>;
}
