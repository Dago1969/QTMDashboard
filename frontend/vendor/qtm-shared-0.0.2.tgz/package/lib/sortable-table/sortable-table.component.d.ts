import { EventEmitter, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export interface QtmSortColumn {
    key: string;
    label: string;
    sortable?: boolean;
    customTemplate?: TemplateRef<unknown> | null;
}
export interface QtmSortState {
    active?: string;
    direction?: 'asc' | 'desc' | null;
}
export declare class QtmSortableTableComponent {
    columns: QtmSortColumn[];
    data: any[];
    totalItems: number;
    page: number;
    pageSize: number;
    pageSizeOptions: number[];
    currentSort: QtmSortState;
    cellTemplates: Record<string, TemplateRef<unknown>>;
    emptyLabel: string;
    pageLabel: string;
    ofLabel: string;
    sortChange: EventEmitter<QtmSortState>;
    pageChange: EventEmitter<number>;
    pageSizeChange: EventEmitter<number>;
    readonly Math: Math;
    get safeColumns(): QtmSortColumn[];
    get safeData(): any[];
    get safeCellTemplates(): Record<string, TemplateRef<unknown>>;
    getCellTemplate(key: string): TemplateRef<unknown> | null;
    getColumnTemplate(column: QtmSortColumn): TemplateRef<unknown> | null;
    get safeCurrentSort(): QtmSortState;
    get totalPages(): number;
    toggleSort(column: QtmSortColumn): void;
    sortIndicator(column: QtmSortColumn): string;
    selectPageSize(value: string): void;
    displayValue(row: any, column: QtmSortColumn): unknown;
    trackByIndex(index: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<QtmSortableTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QtmSortableTableComponent, "qtm-sortable-table", never, { "columns": { "alias": "columns"; "required": false; }; "data": { "alias": "data"; "required": false; }; "totalItems": { "alias": "totalItems"; "required": false; }; "page": { "alias": "page"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; }; "currentSort": { "alias": "currentSort"; "required": false; }; "cellTemplates": { "alias": "cellTemplates"; "required": false; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; }; "pageLabel": { "alias": "pageLabel"; "required": false; }; "ofLabel": { "alias": "ofLabel"; "required": false; }; }, { "sortChange": "sortChange"; "pageChange": "pageChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}
