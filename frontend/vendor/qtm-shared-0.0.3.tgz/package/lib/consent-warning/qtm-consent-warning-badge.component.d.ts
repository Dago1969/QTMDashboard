import * as i0 from "@angular/core";
export declare class QtmConsentWarningBadgeComponent {
    consentRevoked: boolean;
    tooltip: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<QtmConsentWarningBadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QtmConsentWarningBadgeComponent, "qtm-consent-warning-badge", never, { "consentRevoked": { "alias": "consentRevoked"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; }, {}, never, never, true, never>;
}
